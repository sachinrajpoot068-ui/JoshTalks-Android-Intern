# JoshTalksApp (Generated)

This is a generated Android Studio project implementing the Josh Talks Android Intern assignment.
I recreated the full project structure and included the task PDF in `app/src/main/assets/`.

Copied uploaded task PDF into project at app/src/main/assets/Android_Intern_Task.pdf
Original path: /mnt/data/Android Intern - Humanness by Josh Talks (1) (1).pdf


## Build & Run
1. Open this directory in Android Studio (preferably Arctic Fox or newer).
2. Sync Gradle.
3. Run the `app` module on a device/emulator (minSdk 24+).
4. Build APK via *Build -> Build Bundle(s) / APK(s) -> Build APK(s).*

