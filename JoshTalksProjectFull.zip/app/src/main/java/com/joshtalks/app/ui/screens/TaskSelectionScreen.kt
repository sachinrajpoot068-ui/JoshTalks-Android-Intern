package com.joshtalks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TaskSelectionScreen(onSelect: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Button(onClick = { onSelect("text_reading") }, modifier = Modifier.fillMaxWidth(0.8f)) { Text("Text Reading Task") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { onSelect("image_description") }, modifier = Modifier.fillMaxWidth(0.8f)) { Text("Image Description Task") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { onSelect("photo_capture") }, modifier = Modifier.fillMaxWidth(0.8f)) { Text("Photo Capture Task") }
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = { onSelect("history") }, modifier = Modifier.fillMaxWidth(0.6f)) { Text("View Task History") }
    }
}
