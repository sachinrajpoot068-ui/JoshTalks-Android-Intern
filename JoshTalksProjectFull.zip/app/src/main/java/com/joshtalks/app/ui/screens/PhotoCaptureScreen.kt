package com.joshtalks.app.ui.screens

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import com.joshtalks.app.data.TaskRepository

@Composable
fun PhotoCaptureScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { TaskRepository(ctx) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var description by remember { mutableStateOf("") }

    val takePhotoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        // returns boolean
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Button(onClick = {
            val uri = createImageUri(ctx)
            photoUri = uri
            takePhotoLauncher.launch(uri)
        }) { Text("Capture Image") }

        Spacer(modifier = Modifier.height(12.dp))
        if (photoUri != null) {
            Image(painter = rememberImagePainter(photoUri), contentDescription = null, modifier = Modifier.size(240.dp))
        }

        Spacer(modifier = Modifier.height(12.dp))
        BasicTextField(value = description, onValueChange = { description = it }, modifier = Modifier.fillMaxWidth())

        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            if (photoUri != null) {
                // store local path as uri.toString()
                repo.createPhotoCapture(imagePath = photoUri.toString(), audioPath = null, duration = 0)
                onDone()
            }
        }, enabled = photoUri != null) { Text("Submit") }
    }
}

fun createImageUri(context: Context): Uri? {
    val contentResolver = context.contentResolver
    val cv = ContentValues()
    cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
    cv.put(MediaStore.Images.Media.DISPLAY_NAME, "photo_${System.currentTimeMillis()}.jpg")
    return contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
}
