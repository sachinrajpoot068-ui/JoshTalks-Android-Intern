package com.joshtalks.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.joshtalks.app.ui.screens.*

@Composable
fun AppNav(modifier: Modifier = Modifier) {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = "start") {
        composable("start") { StartScreen(onStart = { nav.navigate("noise") }) }
        composable("noise") { NoiseTestScreen(onPassed = { nav.navigate("tasks") }) }
        composable("tasks") { TaskSelectionScreen(onSelect = { type -> nav.navigate(type) }) }

        composable("text_reading") { TextReadingScreen(onDone = { nav.navigate("tasks") }) }
        composable("image_description") { ImageDescriptionScreen(onDone = { nav.navigate("tasks") }) }
        composable("photo_capture") { PhotoCaptureScreen(onDone = { nav.navigate("tasks") }) }
        composable("history") { TaskHistoryScreen() }
    }
}
