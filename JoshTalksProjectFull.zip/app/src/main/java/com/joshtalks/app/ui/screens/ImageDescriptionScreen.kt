package com.joshtalks.app.ui.screens

import android.media.MediaPlayer
import android.media.MediaRecorder
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import com.joshtalks.app.data.TaskRepository
import java.io.File
import java.util.UUID
import androidx.compose.foundation.gestures.detectTapGestures

@Composable
fun ImageDescriptionScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { TaskRepository(ctx) }
    val imageUrl = "https://cdn.dummyjson.com/product-images/14/2.jpg"

    var recordingPath by remember { mutableStateOf<String?>(null) }
    var durationSec by remember { mutableStateOf(0) }
    var recorder: MediaRecorder? by remember { mutableStateOf(null) }
    var startMs by remember { mutableStateOf(0L) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painter = rememberImagePainter(imageUrl), contentDescription = null, modifier = Modifier.size(240.dp))
        Spacer(modifier = Modifier.height(12.dp))
        Text("Describe what you see in your native language.")

        Box(modifier = Modifier
            .size(96.dp)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    val file = File(ctx.filesDir, "audio_${UUID.randomUUID()}.mp3")
                    try {
                        recorder = MediaRecorder().apply {
                            setAudioSource(MediaRecorder.AudioSource.MIC)
                            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                            setOutputFile(file.absolutePath)
                            prepare()
                            start()
                        }
                        startMs = System.currentTimeMillis()
                    } catch (e: Exception) { Log.e("REC", "start fail", e) }

                    tryAwaitRelease()
                    val end = System.currentTimeMillis()
                    try { recorder?.apply { stop(); release() } } catch (e: Exception) {}
                    val dur = ((end - startMs) / 1000).toInt()
                    recorder = null
                    if (dur < 10) {
                        recordingPath = null; durationSec = 0
                    } else if (dur > 20) {
                        recordingPath = null; durationSec = 0
                    } else {
                        val f = ctx.filesDir.listFiles()?.maxByOrNull { it.lastModified() }
                        recordingPath = f?.absolutePath
                        durationSec = dur
                    }
                })
        ) { Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Mic") } }

        Spacer(modifier = Modifier.height(12.dp))
        Button(onClick = {
            if (recordingPath != null) {
                repo.createImageDescription(imageUrl, recordingPath!!, durationSec)
                onDone()
            }
        }, enabled = recordingPath != null) { Text("Submit") }
    }
}
