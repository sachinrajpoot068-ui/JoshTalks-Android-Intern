package com.joshtalks.app.ui.screens

import android.Manifest
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.Button
import androidx.compose.material.Checkbox
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.delay
import java.io.File
import java.util.UUID
import com.joshtalks.app.data.TaskRepository
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures

@Composable
fun TextReadingScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val repo = remember { TaskRepository(ctx) }
    var passage by remember { mutableStateOf("") }
    var recordingPath by remember { mutableStateOf<String?>(null) }
    var durationSec by remember { mutableStateOf(0) }
    var recorder: MediaRecorder? by remember { mutableStateOf(null) }
    var startMs by remember { mutableStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var player: MediaPlayer? by remember { mutableStateOf(null) }

    // fetch sample text from dummyjson - simplified: hardcode fallback
    LaunchedEffect(Unit) {
        passage = "This is a sample text for reading. Please read this passage aloud in your native language as instructed." // fallback
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = passage)
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Press and hold the mic to record (10-20s)")

        // Simple press-and-hold area using pointerInput - start on down, stop on up
        Box(modifier = Modifier
            .size(96.dp)
            .background(color = androidx.compose.material.MaterialTheme.colors.primary)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    // start
                    val file = File(ctx.filesDir, "audio_${UUID.randomUUID()}.mp3")
                    try {
                        recorder = MediaRecorder().apply {
                            setAudioSource(MediaRecorder.AudioSource.MIC)
                            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                            setOutputFile(file.absolutePath)
                            prepare()
                            start()
                        }
                        startMs = System.currentTimeMillis()
                    } catch (e: Exception) { Log.e("REC", "start fail", e) }

                    val released = tryAwaitRelease()
                    // on release
                    val end = System.currentTimeMillis()
                    try {
                        recorder?.apply { stop(); release() }
                    } catch (e: Exception) { }
                    val dur = ((end - startMs) / 1000).toInt()
                    recorder = null
                    if (dur < 10) {
                        // show error
                        recordingPath = null
                        durationSec = 0
                        // show snackbar? For simplicity, change passage
                        passage = "Recording too short (min 10 s)."
                    } else if (dur > 20) {
                        recordingPath = null
                        durationSec = 0
                        passage = "Recording too long (max 20 s)."
                    } else {
                        // find the last file in filesDir
                        val f = ctx.filesDir.listFiles()?.maxByOrNull { it.lastModified() }
                        recordingPath = f?.absolutePath
                        durationSec = dur
                        passage = "Recorded OK: $dur s"
                    }
                })
        ) { Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Mic") } }

        Spacer(modifier = Modifier.height(12.dp))

        // Checkboxes
        var c1 by remember { mutableStateOf(false) }
        var c2 by remember { mutableStateOf(false) }
        var c3 by remember { mutableStateOf(false) }
        Row { Checkbox(checked = c1, onCheckedChange = { c1 = it }); Text("No background noise") }
        Row { Checkbox(checked = c2, onCheckedChange = { c2 = it }); Text("No mistakes while reading") }
        Row { Checkbox(checked = c3, onCheckedChange = { c3 = it }); Text("Beech me koi galti nahi hai") }

        Spacer(modifier = Modifier.height(12.dp))

        Row {
            Button(onClick = { recordingPath = null; durationSec = 0; passage = "Ready to record again" }) { Text("Record again") }
            Spacer(modifier = Modifier.width(8.dp))
            val canSubmit = recordingPath != null && c1 && c2 && c3
            Button(onClick = {
                if (canSubmit) {
                    repo.createTextReading(text = passage.take(200), audioPath = recordingPath!!, duration = durationSec)
                    onDone()
                }
            }, enabled = canSubmit) { Text("Submit") }
        }
    }
}
