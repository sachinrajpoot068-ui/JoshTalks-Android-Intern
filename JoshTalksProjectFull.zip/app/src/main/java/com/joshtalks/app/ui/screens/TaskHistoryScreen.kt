package com.joshtalks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.joshtalks.app.data.TaskRepository

@Composable
fun TaskHistoryScreen() {
    val ctx = LocalContext.current
    val repo = TaskRepository(ctx)
    val tasks = repo.all()
    val totalDuration = tasks.sumOf { it.duration_sec }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Total Tasks: ${tasks.size}")
            Text("Total Duration: ${totalDuration}s")
        }
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks) { t ->
                Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                    Text("ID: ${t.id}")
                    Text("Type: ${t.task_type}")
                    Text("Duration: ${t.duration_sec} s | ${t.timestamp}")
                    if (t.text != null) Text("Snippet: ${t.text.take(80)}")
                    if (t.image_url != null) Text("Image URL: ${t.image_url}")
                    if (t.image_path != null) Text("Image Path: ${t.image_path}")
                }
            }
        }
    }
}
