package com.joshtalks.app.data

import android.content.Context
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.UUID

class TaskRepository(context: Context) {
    private val storage = LocalStorage(context)
    private val tasks = storage.loadTasks()

    fun all(): List<Task> = tasks

    fun add(task: Task) {
        tasks.add(0, task)
        storage.saveTasks(tasks)
    }

    fun createTextReading(text: String, audioPath: String, duration: Int) {
        val t = Task(
            id = UUID.randomUUID().toString(),
            task_type = "text_reading",
            text = text,
            audio_path = audioPath,
            duration_sec = duration,
            timestamp = now()
        )
        add(t)
    }

    fun createImageDescription(imageUrl: String?, audioPath: String, duration: Int) {
        val t = Task(
            id = UUID.randomUUID().toString(),
            task_type = "image_description",
            image_url = imageUrl,
            audio_path = audioPath,
            duration_sec = duration,
            timestamp = now()
        )
        add(t)
    }

    fun createPhotoCapture(imagePath: String, audioPath: String?, duration: Int) {
        val t = Task(
            id = UUID.randomUUID().toString(),
            task_type = "photo_capture",
            image_path = imagePath,
            audio_path = audioPath,
            duration_sec = duration,
            timestamp = now()
        )
        add(t)
    }

    private fun now(): String {
        val f = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(ZoneOffset.UTC)
        return f.format(Instant.now())
    }
}
