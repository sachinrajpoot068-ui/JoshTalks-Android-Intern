package com.joshtalks.app.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

class LocalStorage(private val context: Context) {
    private val fileName = "tasks.json"

    fun loadTasks(): MutableList<Task> {
        val file = File(context.filesDir, fileName)
        if (!file.exists()) return mutableListOf()
        return try {
            val text = file.readText()
            Json.decodeFromString(text)
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveTasks(tasks: List<Task>) {
        val file = File(context.filesDir, fileName)
        val str = Json.encodeToString(tasks)
        file.writeText(str)
    }
}
