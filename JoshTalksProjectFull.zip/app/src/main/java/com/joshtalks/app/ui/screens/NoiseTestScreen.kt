package com.joshtalks.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun NoiseTestScreen(onPassed: () -> Unit) {
    var running by remember { mutableStateOf(false) }
    var avgDb by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(text = "Noise Test")
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = "Decibel: $avgDb dB (0-60)")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (!running) {
                running = true
                // simulate a 3-second test and produce an average
                LaunchedEffect(Unit) {
                    var sum = 0
                    repeat(6) {
                        val v = (15..55).random()
                        sum += v
                        avgDb = sum / (it + 1)
                        delay(300)
                    }
                    running = false
                    if (avgDb < 40) {
                        message = "Good to proceed"
                        onPassed()
                    } else {
                        message = "Please move to a quieter place"
                    }
                }
            }
        }) {
            if (running) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Testing...")
            } else Text(text = "Start Test")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(text = message)
    }
}
