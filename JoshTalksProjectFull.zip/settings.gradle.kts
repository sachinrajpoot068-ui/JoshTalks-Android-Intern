rootProject.name = "JoshTalksApp"
include(":app")
