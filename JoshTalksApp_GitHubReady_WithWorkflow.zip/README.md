# JoshTalksApp
Generated project for Josh Talks assignment.


## GitHub Actions
A workflow has been added at `.github/workflows/android-build.yml`. When you push this repo to GitHub (branch `main`), GitHub Actions will build the debug APK and make it available as an artifact named `app-debug-apk`.
